const express = require("express");
const app = express();

const Bicycles = require("./data/data.json");

app.set('view engine' , 'ejs'); // means that the view engine is supporting the files with the ejs extensions
app.use(express.static("public"));

app.get("/" , (req ,res) =>{
    
    console.log(Bicycles);
    return res.render('bicycles' , {
        Bicycles

    }); //we have used render here to upload the templates otherwise we can also use send
});
app.get("/bicycle" , (req ,res) =>{

    const bicycle = Bicycles.find(b=>b.id === req.query.id);
    console.log(bicycle);
     return res.render('overview' , {
        bicycle
     });
});
app.listen(3000 , () =>{
    console.log("the server has started");
});